from django.contrib import admin
from .models import Mensajes
# Register your models here.
admin.site.register(Mensajes)
