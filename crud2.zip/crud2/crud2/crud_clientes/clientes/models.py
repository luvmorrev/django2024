from django.db import models


# Create your models here.
class Mensajes(models.Model):
    id=models.AutoField(primary_key=True)
    mensaje= models.TextField(max_length=40,verbose_name='Mensajes')
    autor= models.CharField(max_length=40,verbose_name='Autor de Mensajes')
    
    
    def __str__(self):
        fila="Id:"+str(self.id)+"-"+"Mensajes:"+self.mensaje+"-"+"Autor de Mensajes:"+self.autor
        return fila
        return super().__str__()
    def delete(self, using=None,keep_parent=False):
        self.foto.storage.delete(self.foto.name)
        super().delete()